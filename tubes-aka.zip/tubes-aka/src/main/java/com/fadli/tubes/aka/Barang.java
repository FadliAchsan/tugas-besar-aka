/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.fadli.tubes.aka;

/**
 *
 * @author Lenovo
 */
public class Barang {
    private String nama;
    private double harga;
    private int jumlah;

    public Barang(String nama, double harga, int jumlah) {
        this.nama = nama;
        this.harga = harga;
        this.jumlah = jumlah;
    }

    public double getHarga() {
        return harga;
    }

    public int getJumlah() {
        return jumlah;
    }

    @Override
    public String toString() {
        return nama + " - Rp" + harga + " x " + jumlah + " = Rp" + (harga * jumlah);
    }
}