/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.fadli.tubes.aka;

import java.util.ArrayList;
import java.util.Scanner;
/**
 *
 * @author Lenovo
 */
public class TubesAka {
static ArrayList<String> inventory = new ArrayList<>();
    static Scanner scanner = new Scanner(System.in);

    public static void main(String[] args) {
        int choice;

        do {
            System.out.println("\n=== Manajemen Inventaris Toko Elektronik ===");
            System.out.println("1. Tambahkan Barang (Iteratif)");
            System.out.println("2. Tambahkan Barang (Rekursif)");
            System.out.println("3. Lihat Inventaris");
            System.out.println("4. Analisis Performa");
            System.out.println("5. Keluar");
            System.out.print("Pilih opsi: ");
            choice = scanner.nextInt();

            switch (choice) {
                case 1:
                    addItemsIterativeMenu();
                    break;
                case 2:
                    addItemsRecursiveMenu();
                    break;
                case 3:
                    displayInventory();
                    break;
                case 4:
                    analyzePerformance();
                    break;
                case 5:
                    System.out.println("Keluar dari program. Terima kasih!");
                    break;
                default:
                    System.out.println("Opsi tidak valid. Silakan coba lagi.");
            }
        } while (choice != 5);
    }

    // Menu untuk menambahkan barang secara iteratif
    private static void addItemsIterativeMenu() {
        System.out.print("Masukkan jumlah barang yang ingin ditambahkan (Iteratif): ");
        int n = scanner.nextInt();
        long startTime = System.nanoTime();
        addItemsIterative(n);
        long endTime = System.nanoTime();
        System.out.println(n + " barang telah ditambahkan menggunakan algoritma iteratif.");
        System.out.println("Waktu eksekusi: " + (endTime - startTime) + " nanodetik.");
    }

    // Menu untuk menambahkan barang secara rekursif
    private static void addItemsRecursiveMenu() {
        System.out.print("Masukkan jumlah barang yang ingin ditambahkan (Rekursif): ");
        int n = scanner.nextInt();
        long startTime = System.nanoTime();
        addItemsRecursive(n, 0);
        long endTime = System.nanoTime();
        System.out.println(n + " barang telah ditambahkan menggunakan algoritma rekursif.");
        System.out.println("Waktu eksekusi: " + (endTime - startTime) + " nanodetik.");
    }

    // Fungsi iteratif untuk menambahkan barang
    public static void addItemsIterative(int n) {
        for (int i = 0; i < n; i++) {
            inventory.add("Barang " + (inventory.size() + 1));
        }
    }

    // Fungsi rekursif untuk menambahkan barang
    public static void addItemsRecursive(int n, int count) {
        if (count < n) {
            inventory.add("Barang " + (inventory.size() + 1));
            addItemsRecursive(n, count + 1);
        }
    }

    // Menampilkan semua barang di inventaris
    public static void displayInventory() {
        if (inventory.isEmpty()) {
            System.out.println("Inventaris kosong.");
        } else {
            System.out.println("Daftar Inventaris:");
            for (String item : inventory) {
                System.out.println(item);
            }
        }
    }

    // Analisis performa algoritma iteratif dan rekursif
    public static void analyzePerformance() {
        int[] inputSizes = {1, 10, 100, 1000};
        System.out.println("\n=== Analisis Performa ===");
        System.out.println("Ukuran Input | Iteratif (ms) | Rekursif (ms)");

        for (int n : inputSizes) {
            // Iteratif
            long startIterative = System.nanoTime();
            addItemsIterative(n);
            long endIterative = System.nanoTime();
            long iterativeTime = (endIterative - startIterative) / 1000;

            // Rekursif
            long startRecursive = System.nanoTime();
            addItemsRecursive(n, 0);
            long endRecursive = System.nanoTime();
            long recursiveTime = (endRecursive - startRecursive) / 1000;

            System.out.printf("%12d | %12d | %12d%n", n, iterativeTime, recursiveTime);

            // Clear inventory after each test
            inventory.clear();
        }

        System.out.println("\nCatatan: Waktu eksekusi dalam milidetik (ms).");
        System.out.println("Iteratif cenderung lebih cepat karena overhead fungsi rekursif.");
    }
}
